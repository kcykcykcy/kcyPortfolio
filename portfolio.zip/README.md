# portfolio 기능

>> router 이용해 페이지 이동
>> pinia 이용해 메뉴명 설정
>> axios 이용해 skill 및 projects 리스트 설정
>> fomantic ui로 버튼 디자인

>> 미디어쿼리 (기본 / 1024px / 768px)